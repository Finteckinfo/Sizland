---
name: Sovereign Infrastructure System
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#edffe1'
  on-secondary: '#013a00'
  secondary-container: '#28ff1d'
  on-secondary-container: '#027100'
  tertiary: '#c3c0ff'
  on-tertiary: '#1d00a5'
  tertiary-container: '#9a98ff'
  on-tertiary-container: '#2300bf'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#77ff61'
  secondary-fixed-dim: '#02e600'
  on-secondary-fixed: '#002200'
  on-secondary-fixed-variant: '#015300'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  terminal-green: '#10B981'
  neon-accent: '#00FF00'
  encryption-purple: '#4F46E5'
  surface-base: '#0A0A0A'
  surface-elevated: '#1A1A1A'
  border-subtle: '#262626'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for the "sovereign remote worker"—individuals who prioritize autonomy, privacy, and technical excellence. The brand personality is **invisible yet omnipresent**, acting as a silent orchestrator of professional workflows rather than a distracting consumer app. It evokes a sense of **technical authority** and **security**, feeling like a high-end command center for "off-the-grid" digital operations.

The visual direction is a fusion of **Minimalism** and **Modern Corporate**, flavored with a "Cyber-Infrastructure" edge. It utilizes a strict dark-mode foundation to reduce eye strain during long-haul deep work. The aesthetic is modular, emphasizing interconnected nodes and clean data structures over decorative fluff. Every element must feel functional, intentional, and censorship-resistant.

## Colors

This design system is built on a **Deep Forest/Infrastructure Dark** palette. 

- **Primary:** `terminal-green` (#10B981) is the core brand color, used for primary actions and status indicators representing "online" or "secure."
- **Secondary:** `neon-accent` (#00FF00) is used sparingly for high-criticality data or highlighting specific nodes in a diagram.
- **Tertiary:** `encryption-purple` (#4F46E5) serves as a secondary accent to denote background processes, encryption layers, or decentralized network activity.
- **Neutral:** The background is an absolute near-black (#0A0A0A) to ensure high contrast for technical readouts. Grays are neutral-cool to maintain a "high-tech" professional feel.

## Typography

Typography focuses on **Technical Authority**. 

**Hanken Grotesk** is used for headlines, providing a sharp, contemporary, and engineered look. 
**Inter** is the workhorse for all body copy and interface text, chosen for its unparalleled legibility in complex layouts. 
**JetBrains Mono** is utilized for labels, metadata, and "node IDs," reinforcing the feeling of an operating system and highlighting the user's sovereign control over data.

All caps should be used exclusively for mono-spaced labels and small metadata tags. Headline sizes scale down for mobile screens to maintain readable density without breaking modular layouts.

## Layout & Spacing

The layout follows a **Rigid Grid System** reflecting the modular nature of an operating system. 

- **Desktop:** A 12-column grid with a fixed 1440px max-width. Large 48px margins create "breathing room" that feels premium and focused.
- **Modular Nodes:** Information should be grouped into "Cells" or "Nodes" that occupy specific spans (e.g., 3-column, 6-column).
- **Rhythm:** An 8px base unit (derived from the 4px micro-unit) governs all padding and margins.
- **Reflow:** On mobile, columns collapse into a single-stack vertical flow, with margins reduced to 16px to maximize data visibility. Elements should maintain their "boxed" appearance even on small screens to preserve the OS metaphor.

## Elevation & Depth

Depth in the design system is achieved through **Tonal Layering** and **Low-Contrast Outlines**. 

Shadows are avoided to keep the interface feeling "flat" and "lightweight," like a low-latency terminal. Instead, depth is communicated by shifting the background color:
- **Level 0 (Base):** #0A0A0A (Background)
- **Level 1 (Card/Container):** #1A1A1A (Raised surface)
- **Level 2 (Active/Hover):** #262626 (Interactive surface)

To separate elements, use 1px borders in `border-subtle` (#262626). For high-priority active states, a 1px border of `terminal-green` is preferred over a shadow. This creates a "glass-terminal" effect without the blur-heavy performance cost of traditional glassmorphism.

## Shapes

The shape language is **Soft-Technical**. We avoid perfectly sharp corners to maintain a professional, finished feel, but we also avoid overly rounded "bubbly" shapes that feel like consumer social media. 

Standard components use a **4px (0.25rem)** radius. This subtle rounding provides a precise, modern look that fits a modular grid. Only specific "Status Nodes" or indicator pips may use a fully rounded/pill shape to distinguish them from structural UI elements.

## Components

- **Buttons:** Primary buttons use a solid `terminal-green` background with black text. Secondary buttons are "ghost" style with a `border-subtle` and white text. No gradients.
- **Input Fields:** Darker than the card background, using `jetbrainsMono` for text entry to emphasize data input. Focus states should use a sharp 1px `terminal-green` border.
- **Chips/Status:** Use mono-spaced font. For "Sovereign" or "Secure" status, use a small 8px solid `terminal-green` dot next to the label.
- **Cards/Nodes:** Modular containers with a 1px `border-subtle`. Header areas of cards should be separated by a thin horizontal line.
- **Iconography:** Use thick, 2px stroke-based icons. Avoid rounded ends; use square caps. Icons should represent infrastructure (e.g., servers, nodes, links, shielding) rather than abstract financial symbols.
- **List Items:** High-density lists with subtle dividers. Each item should feel like a row in a database, optimized for rapid scanning.